/* Michael Wang, Daniel Chung
   Ms. Basaraba
   June 2, 2023
   Class checks validity of user input */
   
import java.util.Calendar;
import java.text.SimpleDateFormat;

/**
*DataCheck class.
*Checks if the data is valid.
*Michael Wang.
*/
public class DataCheck{
   /**
   *counts the number of @ symbols in the email
   */
   private static int atCount;
   /**
   *DataCheck constructor
   */
   public DataCheck(){
   }
   
   /**
   *Method checks validity of phone number
   *@param input the user input given
   *@return boolean of validity
   */
   public static boolean checkPhone(String input){
      if (input.length() == 10){
         if (isNumeric(input))
            return true;
         else
            return false;
      }
      else if (input.length() == 12){
         if ((input.charAt(3) == '-' && input.charAt(7) == '-')||(input.charAt(3) == ' ' && input.charAt(7) == ' ')){
            try{
               if (isNumeric(input.substring(0, 2)) && isNumeric(input.substring(4, 6)) && isNumeric(input.substring(8, 11)))
                  return true;
            }
            catch (Exception invalid){
               return false;
            }
         }  
      }
      else{
         return false;
      }
      return true;
   }
   
   /**
   *Method checks validity of email
   *@param input the user input given
   *@return boolean of validity
   */
   public static boolean checkEmail(String input){
      atCount = 0;
      for (int i = 0; i < input.length(); i++){
         if (input.charAt(i) == '@'){
            if (i == 0 || i == (input.length()-1) || atCount == 1)
               return false;
            else
               atCount++;
         }
      }
      if (atCount == 0)
         return false;
      return true;
   }
   /**
   *Method checks validity of date of birth
   *@param input the user input given
   *@return boolean of validity
   */
   public static boolean checkDOB(String input){
      if (input.length() == 10){
         if ((input.charAt(2) == '/' && input.charAt(5) == '/')){
            try{
               if (Integer.parseInt(input.substring(0, 2)) < 13 && Integer.parseInt(input.substring(0, 2)) > 0){
                  if (Integer.parseInt(input.substring(0, 2)) == 2){
                     if ((Integer.parseInt(input.substring(3, 5)) < 29) && (Integer.parseInt(input.substring(3, 5)) > 0) && (Integer.parseInt(input.substring(6, 10)) > 0) && (Integer.parseInt(input.substring(6, 10)) < 2024))
                        return true;
                     else
                        return false;
                  }
                  else if ((Integer.parseInt(input.substring(0, 2)) == 1 )|| (Integer.parseInt(input.substring(0, 2)) == 3 )|| (Integer.parseInt(input.substring(0, 2)) == 5 )|| (Integer.parseInt(input.substring(0, 2)) == 7 )|| (Integer.parseInt(input.substring(0, 2)) == 8 )|| (Integer.parseInt(input.substring(0, 2)) == 10 )|| (Integer.parseInt(input.substring(0, 2)) == 12 )){
                     if ((Integer.parseInt(input.substring(3, 5)) < 32) && (Integer.parseInt(input.substring(3, 5)) > 0) && (Integer.parseInt(input.substring(6, 10)) > 0) && (Integer.parseInt(input.substring(6, 10)) < 2024))
                        return true;
                     else
                        return false;
                  }
                  else {
                     if ((Integer.parseInt(input.substring(3, 5)) < 31) && (Integer.parseInt(input.substring(3, 5)) > 0) && (Integer.parseInt(input.substring(6, 10)) > 0) && (Integer.parseInt(input.substring(6, 10)) < 2024))
                        return true;
                     else
                        return false;
                  }
               }
               else
                  return false;
            }
            catch (Exception invalid){
               return false;
            }
         }  
      }
      return false;
   }
   /**
   *Method checks if string is numeric
   *@param str String
   *@return boolean of validity
   */
   public static boolean isNumeric (String str) {
      return str.matches("\\d+(\\.\\d+)?");
   }
   
   /**
   *Method checks if age is consistent with date of birth entered
   *@param ageS age
   *@param DOB date of birth
   *@return boolean of validity
   */
   public static boolean checkAge(String ageS, String DOB){
      Calendar calendar = Calendar.getInstance();
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
      String dateString = dateFormat.format(calendar.getTime());
      
      int yearNow = Integer.parseInt(dateString.substring(0,4));
      int monthNow = Integer.parseInt(dateString.substring(5,7));
      int dayNow = Integer.parseInt(dateString.substring(8,10));
      int ageInt = Integer.parseInt(ageS);
      int yearDOB = Integer.parseInt(DOB.substring(6,10));
      int monthDOB = Integer.parseInt(DOB.substring(0,2));
      int dayDOB = Integer.parseInt(DOB.substring(3,5));
 
      
      if(yearNow - yearDOB == ageInt){
         if(monthNow > monthDOB){
               return true;  
         }
         else if(monthNow == monthDOB && dayDOB <= dayNow){
            return true;
         }
         else{
            return false;
         }
      }
      else if(yearNow - yearDOB == ageInt + 1){
         if (monthDOB > monthNow){
            return true;
         }
         else if(monthDOB == monthNow && dayDOB > dayNow){
            return true;
         }
         else{
            return false;
         }
      }
      else{
         return false;
      }
   }    
}