/* Daniel Chung
   Ms. Basaraba
   June 08, 2023
   The purpose of this program is to print the passenger manifest  */
   
/* Modification
   June 7 2023
   Daniel Chung
   20 min
   Version 4
   Created PrintPassengers class, methods quickSort, partition, swap, printPassengers */
   
/* Modification
   June 8 2023
   Daniel Chung
   100 min
   Version 4
   Modified methods quickSort, partition, swap, printPassengers. Completed quick sort algorithm, modified printPassengers to access flight data */

/**
* The PrintPassengers class.
* Prints passenger manifest.
* Daniel Chung.
*/
public class PrintPassengers {

   /**
   *Constructor method
   */
   public PrintPassengers(){
   }
   /**
   *Quick sorts passenger last names in alphabetical order
   *@param passengers array of passenger informataion
   *@param low lowest element of subarray
   *@param high highest element of subarray
   */
   public static void quickSort(String[][] passengers, int low, int high) {
      if (low < high) {
         /** index of partition*/
         int pivotIndex = partition(passengers, low, high);
         quickSort(passengers, low, pivotIndex - 1);
         quickSort(passengers, pivotIndex + 1, high);
      }
   }
   
   /**
   *Quick sorts passenger last names in alphabetical order
   *@param passengers array of passenger informataion
   *@param low lowest element of subarray
   *@param high highest element of subarray
   *@return new index
   */
   public static int partition(String[][] passengers, int low, int high) {
      String pivot = passengers[high][2];
      /** index */
      int i = low - 1;

      for (int j = low; j < high; j++) {
         if (passengers[j][2].compareTo(pivot) < 0) {
            i++;
            swap(passengers, i, j);
         }
      }

      swap(passengers, i + 1, high);
      return i + 1;
   }
   /**
   *Swaps two arrays
   *@param passengers two-dimensional array of passengers
   *@param i first array
   *@param j second array
   */
   public static void swap(String[][] passengers, int i, int j) {
      for(int k = 0; k < 7; k++){
         String temp = passengers[i][k];
         passengers[i][k] = passengers[j][k];
         passengers[j][k] = temp; 
      }
   }
   /**
   *Quick sorts passenger last names in alphabetical order
   *@param flightNum flight number
   *@param alphaOrder whether the passenger manifest is printed according to last name alphabetical order
   */
   public static void printPassengers(int flightNum, boolean alphaOrder){
      System.out.println("     ~~ Atlas Airlines ~~");
   System.out.println("");
   System.out.println("            :::----");
   System.out.println("         ::          \\");
   System.out.println("       ::          :   \\");
   System.out.println("      ::         ::     |");
   System.out.println("     :::    ::::::       |");
   System.out.println("      ::  ::::::::      |");
   System.out.println("       ::  :::::::     /");
   System.out.println("         ::          /");
   System.out.println("            :::----");
   System.out.println("");
   System.out.println("~~ Let the air set you free ~~");
      /** two-dimensional array of passengers, including contact information for each*/
      int passengerCount = FlightInfo.getFlightSeatCount(flightNum);

      /** array of passengers */
      String[][] passengers = new String[passengerCount][7];
      
      /** index */
      int j = 0;
      for(int i = 0; i < 10; i++){
         if(i<5){
            if(FlightInfo.checkFlightSeat(flightNum, i, 0)){
               passengers[j][0] = Integer.toString(i+1);
               passengers[j][1] = FlightInfo.getFlightSeatFirstName(flightNum, i, 0);
               passengers[j][2] = FlightInfo.getFlightSeatLastName(flightNum, i, 0);
               passengers[j][3] = FlightInfo.getFlightSeatDOB(flightNum, i, 0);
               passengers[j][4] = Integer.toString(FlightInfo.getFlightSeatAge(flightNum, i, 0));
               passengers[j][5] = FlightInfo.getFlightSeatEmail(flightNum, i, 0);
               passengers[j][6] = FlightInfo.getFlightSeatPhone(flightNum, i, 0);
               j++;
            }  
         }
         else{
            if(FlightInfo.checkFlightSeat(flightNum, i-5, 1)){
               passengers[j][0] = Integer.toString(i+1);
               passengers[j][1] = FlightInfo.getFlightSeatFirstName(flightNum, i-5, 1);
               passengers[j][2] = FlightInfo.getFlightSeatLastName(flightNum, i-5, 1);
               passengers[j][3] = FlightInfo.getFlightSeatDOB(flightNum, i-5, 1);
               passengers[j][4] = Integer.toString(FlightInfo.getFlightSeatAge(flightNum, i-5, 1));
               passengers[j][5] = FlightInfo.getFlightSeatEmail(flightNum, i-5, 1);
               passengers[j][6] = FlightInfo.getFlightSeatPhone(flightNum, i-5, 1);      
               j++;
            }
         }
      }
      
      if(alphaOrder == true){
         quickSort(passengers, 0, passengers.length - 1);
      }
        
      System.out.printf("Flight " + (flightNum + 1) + " Passenger Manifest:");
      System.out.println();
      for (int i = 0; i < passengers.length; i++) {
         System.out.print("Seat Number: ");
         System.out.print(passengers[i][0]);
         System.out.print(" | Name: ");
         System.out.print(passengers[i][1]);
         System.out.print(" ");
         System.out.print(passengers[i][2]);
         System.out.print(" | Date of Birth: ");
         System.out.print(passengers[i][3]);
         System.out.print(" | Age: ");
         System.out.print(passengers[i][4]);
         System.out.print(" | Email: ");
         System.out.print(passengers[i][5]);
         System.out.print(" | Phone Number: ");
         System.out.println(passengers[i][6]);
      }
   }
}
