/* Michael Wang
   Ms. Basaraba
   June 11, 2023
   The purpose of this program is to hold flight types and act as an interface  */
   
/**
* The FlightTypes interface.
* holds flight types.
* Michael Wang.
*/
interface FlightTypes {
   /**holds flight types in a 2d array*/
   public static final Object[][] FLIGHT_TYPES = {{"New York / USA", Integer.valueOf(886), Integer.valueOf(278)}, {"New York / USA", Integer.valueOf(882), Integer.valueOf(285)},{"Timbuktu / Mali", Integer.valueOf(886), Integer.valueOf(2412)}, {"Timbuktu / Mali", Integer.valueOf(882), Integer.valueOf(2328)}, {"Tokyo / Japan", Integer.valueOf(886), Integer.valueOf(2452)}, {"Tokyo / Japan", Integer.valueOf(882), Integer.valueOf(2552)}};
}