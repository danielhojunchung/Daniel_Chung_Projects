/* Michael Wang
   Ms. Basaraba
   June 2, 2023
   The purpose of this program is to open the user manual file*/
   
/* Modification
   May 18 2023
   Michael Wang
   20 min
   Version 1
   Created user manual */

import java.awt.Desktop;
import java.io.*;
import javax.swing.JOptionPane;

/**
*UserManual class.
*Opens user manual.
*Michael Wang
*/
public class UserManual{
    /**file containing the user manual*/
    static File file;
    /**
    *Constructor method
    */
    UserManual(){  
    }
    /**
   *Method opens user manual
   *Modified: put it all in one try catch block and removed the testing print statement, solved some errors.
   */
    public static void openUserManual(){
        try{
            file = new File("C:/Users/335042891/Desktop/Java Code/ISPDraftPre-Final_2/User Manual - ICS.pdf"); //User manual file location, change to wherever it's located
            Desktop desktop = Desktop.getDesktop();
            desktop.open(file);
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null, "User Manual not found!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}