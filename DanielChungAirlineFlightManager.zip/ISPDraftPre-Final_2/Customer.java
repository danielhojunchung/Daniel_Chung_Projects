/* Michael Wang, Daniel Chung
   Ms. Basaraba
   June 2, 2023
   The purpose of this program is to hold the information for a customer. */

public class Customer{
   /** first name of customer*/
   private String firstName;
   /** last name of customer*/
   private String lastName;
   /** date of birth of customer*/
   private String DOB;
   /** age of customer*/
   private int age;
   /** phone number of customer*/
   private String phone;
   /** email of customer*/
   private String email;
   
   /**
   *Constructor
   *@param first first name
   *@param last last name
   *@param DOB date of birth
   *@param age age
   *@param phone phone number
   *@param email email
   */
   public Customer(String first, String last, String DOB, int age, String phone, String email){
      firstName = first;
      lastName = last;
      this.DOB = DOB;
      this.age = age;
      this.phone = phone;
      this.email = email;
   }
   
   /**
   *Retrieves first name
   *@return first name
   */
   public String getFirstName(){
      return firstName;
   }
   /**
   *Retrieves last name
   *@return last name
   */
   public String getLastName(){
      return lastName;
   }
   /**
   *Retrieves date of birth
   *@return date of birth
   */
   public String getDOB(){
      return DOB;
   }
   /**
   *Retrieves age
   *@return age
   */
   public int getAge(){
      return age;
   }
   /**
   *Retrieves email
   *@return email
   */
   public String getEmail(){
      return email;
   }
   /**
   *Retrieves phone number
   *@return phone number
   */
   public String getPhone(){
      return phone;
   }
   /**
   *Writes all customer information onto a single string
   *@return string of customer information
   */
   @Override
   public String toString(){
      return getFirstName() + " " + getLastName() + " " + getDOB() + " " + getAge() + " " + getEmail() + " " + getPhone();
   }
}