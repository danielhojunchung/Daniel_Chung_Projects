/* Michael Wang, Daniel Chung
   Ms. Basaraba
   June 2, 2023
   The purpose of this program is to hold the information for a list of flights. */

import java.awt.*;
import javax.swing.*;
import java.util.*;

/**
*FlightInfo class.
*Stores information for flights
*Michael Wang, Daniel Chung.
*/
public class FlightInfo{
   /** list of flights */
   private static ArrayList<Flight> flightList = new ArrayList<Flight>();
   /**
   *Constructor method
   */
   public FlightInfo(){
   }
   
   /**
   *Retrieves number of flights
   *@return the number of flights
   */
   public static int getFlightNum(){
      return flightList.size();
   }
   
   /**
   *Retrieves date, destination, and number of flight
   *@param y index of flight
   *@return returns the info for the flight at the specified index of the flightList ArrayList
   */
   public static String getFlightNumInfo(int y){
      return flightList.get(y).getDate() + ", " + flightList.get(y).getDestination() + ", " + flightList.get(y).getFlightNumber();
   }
   
   /**
   *Retrives ticket cost
   *@param y flight
   *@return ticket cost
   */
   public static int getFlightTicketCost(int y){
      return flightList.get(y).getTicketCost();
   }
   
   /**
   *Retrives seat count
   *@param y flight
   *@return seat count
   */
   public static int getFlightSeatCount(int y){
      return flightList.get(y).getSeatCount();  
   }
   
   /**
   *Retrives first name
   *@param y flight
   *@param a row
   *@param b column
   *@return first name
   */
   public static String getFlightSeatFirstName(int y, int a, int b){
      return flightList.get(y).getSeatFirstName(a,b);
   }
   
   /**
   *Retrives first name
   *@param y flight
   *@param a row
   *@param b column
   *@return first name
   */
   public static String getFlightSeatLastName(int y, int a, int b){
      return flightList.get(y).getSeatLastName(a,b);
   }
   
   /**
   *Retrives first name
   *@param y flight
   *@param a row
   *@param b column
   *@return first name
   */
   public static String getFlightSeatDOB(int y, int a, int b){
      return flightList.get(y).getSeatDOB(a,b);
   }
   
   /**
   *Retrives first name
   *@param y flight
   *@param a row
   *@param b column
   *@return first name
   */
   public static int getFlightSeatAge(int y, int a, int b){
      return flightList.get(y).getSeatAge(a,b);
   }
   
   /**
   *Retrives first name
   *@param y flight
   *@param a row
   *@param b column
   *@return first name
   */
   public static String getFlightSeatEmail(int y, int a, int b){
      return flightList.get(y).getSeatEmail(a,b);
   }
   
   /**
   *Retrives first name
   *@param y flight
   *@param a row
   *@param b column
   *@return first name
   */
   public static String getFlightSeatPhone(int y, int a, int b){
      return flightList.get(y).getSeatPhone(a,b);
   }
      
   /**
   *Adds inputed flight object to flightList
   *@param f Flight object
   */
   public static void addFlight(Flight f){
      flightList.add(f);
   }
   
   /**
   *Removes specified flight from flightList
   *@param f Flight object
   */
   public static void cancelFlight(int f){
      flightList.remove(f);
   }
   
   /**
   *Checks if seat on flight is taken
   *@param z flight
   *@param zx row
   *@param zy column
   *@return boolean of validity
   */
   public static boolean checkFlightSeat(int z, int zx, int zy){
      return flightList.get(z).checkSeat(zx, zy);
   }
   
   /**
   *Retrieves data for flight
   *Modified: added this
   *@param y flight number on the flight list
   *@return the data for that flight
   */
   public static Object[][] getFlightData(int y){
      return flightList.get(y).getData();
   }
   
   /**
   *Retrives seat data
   *@param y flight
   *@param a row
   *@param b column
   *@return array of customer information
   */
   public static Object[] getFlightSeatData(int y, int a, int b){
      return flightList.get(y).getSeatData(a, b);
   }
   
   /**
   *Sets specified seat for specified flight
   *@param z flight
   *@param x customer for the seat, have customer as null to cancel a seat booking
   *@param zx row
   *@param zy column
   */
   public static void setFlightSeat(int z, Customer x, int zx, int zy){
      flightList.get(z).setSeat(x, zx, zy);
   }
}