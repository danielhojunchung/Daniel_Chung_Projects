/* Michael Wang, Daniel Chung
   Ms. Basaraba
   June 2, 2023
   The purpose of this program is to hold the information a flight. */


/**
* The flight class.
* Stores the information of a flight.
* Michael Wang, Daniel Chung.
*/
public class Flight {
   /** date of flight */
   private String date;
   /** destination of flight */
   private String destination;
   /** flight number of flight */
   private int flightNumber;
   /** array of seats */
   private Customer[][] seats;
   /** array of customer information */
   private Object[][] custInfo;
   /** price of flight tickets */
   private int ticketCost;
   /** number of seats */
   private int seatCount;
   
   /**
   *Constructor method
   *@param date Date
   *@param dest Destination
   *@param fn flight number
   *@param ticketCost ticket cost
   */
   public Flight(String date, String dest, int fn, int ticketCost){
      this.date = date;
      destination = dest;
      flightNumber = fn;
      seats = new Customer [5][2];
      this.ticketCost = ticketCost;
      seatCount = 0;
   }
   /**
   *Retrives ticket cost
   *@return ticket cost
   */
   public int getTicketCost(){
      return ticketCost;
   }
   /**
   *Retrives date
   *@return date 
   */
   public String getDate(){
      return date;
   }
   
   /**
   *Retrives destination
   *@return destination 
   */
   public String getDestination(){
      return destination;
   }
   /**
   *Retrives flight number
   *@return flight number
   */
   public int getFlightNumber(){
      return flightNumber;
   }
   /**
   *Checks if seat is taken
   *@param a row
   *@param b column
   *@return if the seat is taken
   */
   public boolean checkSeat (int a, int b){
      return (seats[a][b] != null);
   } 
   /**
   *Retrives first name of person registered for seat
   *@param a row
   *@param b column
   *@return first name
   */
   public String getSeatFirstName(int a, int b){
      return seats[a][b].getFirstName();
   }
   
   /**
   *Retrives last name of person registered for seat
   *@param a row
   *@param b column
   *@return last name
   */
   public String getSeatLastName(int a, int b){
      return seats[a][b].getLastName();
   }
   
   /**
   *Retrives date of birth of person registered for seat
   *@param a row
   *@param b column
   *@return date of birth
   */
   public String getSeatDOB(int a, int b){
      return seats[a][b].getDOB();
   }
   
   /**
   *Retrieves age of person registered for seat
   *@param a row
   *@param b column
   *@return age of person 
   */
   public int getSeatAge(int a, int b){
      return seats[a][b].getAge();
   }
   
   /**
   *Retrives email of person resgistered for seat
   *@param a row
   *@param b column
   *@return date 
   */
   public String getSeatEmail(int a, int b){
      return seats[a][b].getEmail();
   }
   
   /**
   *Retrives phone number of person resgistered for seat
   *@param a row
   *@param b column
   *@return phone number 
   */
   public String getSeatPhone(int a, int b){
      return seats[a][b].getPhone();
   }
   
   /**
   *Retrives all personal information of person registered for seat
   *Modified: added this
   *@param a row
   *@param b column
   *@return array of details 
   */
   public Object[] getSeatData(int a, int b){
      Object[] array = {Integer.valueOf(a*2+b+1), getSeatFirstName(a, b), getSeatLastName(a, b), getSeatDOB(a, b), Integer.valueOf(getSeatAge(a, b)), getSeatEmail(a, b), getSeatPhone(a, b)};
      return array;
   }
   
   /**
   *Adds to seat count if seat is unfilled
   *@param x Customer
   *@param a row
   *@param b column
   */
   public void setSeat (Customer x, int a, int b){
      seats[a][b] = x;
      if (x != null)
         seatCount++;
      else
         seatCount--;
   }
    
   /**
   *Retrieves data for seats
   *@return array of data for passengers on flight
   */
   public Object[][] getData(){
      int ind = 0;
      custInfo = new Object[seatCount][6];
      for (int i = 0; i < 5; i++){
         for (int j = 0; j < 2; j++){
            if (checkSeat(i, j)){
               custInfo[ind] = getSeatData(i, j);
               ind++;
            }
         }
      }
      return custInfo; 
   }
    
   /**
   *Retrives number of solds seats
   *@return date 
   */ 
   public int getSeatCount(){
      return seatCount;
   }
    
   /*@Override
   public String toString(){
      String output;
      for (*/
}