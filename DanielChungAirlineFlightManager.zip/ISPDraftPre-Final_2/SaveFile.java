/* Michael Wang
   Ms. Basaraba
   June 10, 2023
   This file saves/reads flight information to/from a text file */

/* Modification
   May 18 2023
   Michael Wang
   20 min
   Version 1
   Created SaveFile class */
   
/* Modification
   June 10 2023
   Michael Wang
   100 min
   Version 5
   Added flights  */
   
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import java.awt.*;
import javax.swing.*;

/**
* The SaveFile class.
* Saves/reads flight information to/from a text file
* Michael Wang.
*/
public class SaveFile implements FlightTypes{
   /** directory to file */
   static File dataFile = new File("C:/Users/335042891/Desktop/Java Code/ISPDraftPre-Final_2/data.txt"); //Change to own directory
   /**
   *Constructor method
   */
   public SaveFile(){
   }
   
   /**
   *creates file if missing and creates default data
   */
   public static void createFile(){
      try{
         if(dataFile.createNewFile()){
            //Week1
            FlightInfo.addFlight(new Flight("02:53 / August 1 / 2023", (String)FLIGHT_TYPES[0][0], (int)FLIGHT_TYPES[0][1], (int)FLIGHT_TYPES[0][2]));
            FlightInfo.addFlight(new Flight("09:17 / August 2 / 2023", (String)FLIGHT_TYPES[1][0], (int)FLIGHT_TYPES[1][1], (int)FLIGHT_TYPES[1][2]));
            FlightInfo.addFlight(new Flight("22:35 / August 3 / 2023", (String)FLIGHT_TYPES[5][0], (int)FLIGHT_TYPES[5][1], (int)FLIGHT_TYPES[5][2]));
            FlightInfo.addFlight(new Flight("12:20 / August 4 / 2023", (String)FLIGHT_TYPES[4][0], (int)FLIGHT_TYPES[4][1], (int)FLIGHT_TYPES[4][2]));
            FlightInfo.addFlight(new Flight("19:55 / August 5 / 2023", (String)FLIGHT_TYPES[3][0], (int)FLIGHT_TYPES[3][1], (int)FLIGHT_TYPES[3][2])); //Sat
            FlightInfo.addFlight(new Flight("18:00 / August 5 / 2023", (String)FLIGHT_TYPES[4][0], (int)FLIGHT_TYPES[2][1], (int)FLIGHT_TYPES[2][2])); //Sun
            FlightInfo.addFlight(new Flight("03:27 / August 6 / 2023", (String)FLIGHT_TYPES[2][0], (int)FLIGHT_TYPES[2][1], (int)FLIGHT_TYPES[2][2])); //Sun
            FlightInfo.addFlight(new Flight("09:48 / August 7 / 2023", (String)FLIGHT_TYPES[5][0], (int)FLIGHT_TYPES[5][1], (int)FLIGHT_TYPES[5][2]));
            //Week2
            FlightInfo.addFlight(new Flight("07:08 / August 8 / 2023", (String)FLIGHT_TYPES[1][0], (int)FLIGHT_TYPES[1][1], (int)FLIGHT_TYPES[1][2]));
            FlightInfo.addFlight(new Flight("05:11 / August 9 / 2023", (String)FLIGHT_TYPES[5][0], (int)FLIGHT_TYPES[5][1], (int)FLIGHT_TYPES[5][2]));
            FlightInfo.addFlight(new Flight("22:19 / August 10 / 2023", (String)FLIGHT_TYPES[2][0], (int)FLIGHT_TYPES[2][1], (int)FLIGHT_TYPES[2][2]));
            FlightInfo.addFlight(new Flight("09:41 / August 11 / 2023", (String)FLIGHT_TYPES[2][0], (int)FLIGHT_TYPES[2][1], (int)FLIGHT_TYPES[2][2]));
            FlightInfo.addFlight(new Flight("03:47 / August 12 / 2023", (String)FLIGHT_TYPES[4][0], (int)FLIGHT_TYPES[4][1], (int)FLIGHT_TYPES[4][2])); //Sat
            FlightInfo.addFlight(new Flight("23:45 / August 12 / 2023", (String)FLIGHT_TYPES[3][0], (int)FLIGHT_TYPES[3][1], (int)FLIGHT_TYPES[3][2])); //Sat
            FlightInfo.addFlight(new Flight("05:00 / August 13 / 2023", (String)FLIGHT_TYPES[0][0], (int)FLIGHT_TYPES[0][1], (int)FLIGHT_TYPES[0][2])); //Sun
            FlightInfo.addFlight(new Flight("14:06 / August 14 / 2023", (String)FLIGHT_TYPES[1][0], (int)FLIGHT_TYPES[1][1], (int)FLIGHT_TYPES[1][2]));
            //Week3
            FlightInfo.addFlight(new Flight("06:48 / August 15 / 2023", (String)FLIGHT_TYPES[2][0], (int)FLIGHT_TYPES[2][1], (int)FLIGHT_TYPES[2][2]));
            FlightInfo.addFlight(new Flight("19:28 / August 16 / 2023", (String)FLIGHT_TYPES[3][0], (int)FLIGHT_TYPES[3][1], (int)FLIGHT_TYPES[3][2]));
            FlightInfo.addFlight(new Flight("13:36 / August 17 / 2023", (String)FLIGHT_TYPES[3][0], (int)FLIGHT_TYPES[3][1], (int)FLIGHT_TYPES[3][2]));
            FlightInfo.addFlight(new Flight("12:35 / August 18 / 2023", (String)FLIGHT_TYPES[1][0], (int)FLIGHT_TYPES[1][1], (int)FLIGHT_TYPES[1][2]));
            FlightInfo.addFlight(new Flight("18:55 / August 19 / 2023", (String)FLIGHT_TYPES[2][0], (int)FLIGHT_TYPES[2][1], (int)FLIGHT_TYPES[2][2])); //Sat
            FlightInfo.addFlight(new Flight("06:25 / August 19 / 2023", (String)FLIGHT_TYPES[4][0], (int)FLIGHT_TYPES[4][1], (int)FLIGHT_TYPES[4][2])); //Sat
            FlightInfo.addFlight(new Flight("17:51 / August 20 / 2023", (String)FLIGHT_TYPES[0][0], (int)FLIGHT_TYPES[0][1], (int)FLIGHT_TYPES[0][2])); //Sun
            FlightInfo.addFlight(new Flight("05:31 / August 21 / 2023", (String)FLIGHT_TYPES[5][0], (int)FLIGHT_TYPES[5][1], (int)FLIGHT_TYPES[5][2]));
            //Week4
            FlightInfo.addFlight(new Flight("01:18 / August 22 / 2023", (String)FLIGHT_TYPES[1][0], (int)FLIGHT_TYPES[1][1], (int)FLIGHT_TYPES[1][2]));
            FlightInfo.addFlight(new Flight("18:08 / August 24 / 2023", (String)FLIGHT_TYPES[4][0], (int)FLIGHT_TYPES[4][1], (int)FLIGHT_TYPES[4][2]));
            FlightInfo.addFlight(new Flight("01:59 / August 25 / 2023", (String)FLIGHT_TYPES[2][0], (int)FLIGHT_TYPES[2][1], (int)FLIGHT_TYPES[2][2]));
            FlightInfo.addFlight(new Flight("17:59 / August 26 / 2023", (String)FLIGHT_TYPES[0][0], (int)FLIGHT_TYPES[0][1], (int)FLIGHT_TYPES[0][2])); //Sat
            FlightInfo.addFlight(new Flight("02:53 / August 27 / 2023", (String)FLIGHT_TYPES[0][0], (int)FLIGHT_TYPES[0][1], (int)FLIGHT_TYPES[0][2])); //Sun
            FlightInfo.addFlight(new Flight("04:37 / August 27 / 2023", (String)FLIGHT_TYPES[3][0], (int)FLIGHT_TYPES[3][1], (int)FLIGHT_TYPES[3][2])); //Sun
            FlightInfo.addFlight(new Flight("09:17 / August 27 / 2023", (String)FLIGHT_TYPES[5][0], (int)FLIGHT_TYPES[5][1], (int)FLIGHT_TYPES[5][2])); //Sun
            FlightInfo.addFlight(new Flight("07:55 / August 28 / 2023", (String)FLIGHT_TYPES[1][0], (int)FLIGHT_TYPES[1][1], (int)FLIGHT_TYPES[1][2]));
            //Week4.5
            FlightInfo.addFlight(new Flight("02:38 / August 29 / 2023", (String)FLIGHT_TYPES[0][0], (int)FLIGHT_TYPES[0][1], (int)FLIGHT_TYPES[0][2]));
            FlightInfo.addFlight(new Flight("05:22 / August 30 / 2023", (String)FLIGHT_TYPES[2][0], (int)FLIGHT_TYPES[0][1], (int)FLIGHT_TYPES[0][2]));
            FlightInfo.addFlight(new Flight("16:22 / August 31 / 2023", (String)FLIGHT_TYPES[1][0], (int)FLIGHT_TYPES[0][1], (int)FLIGHT_TYPES[0][2]));
            }
      }
      catch (IOException e){
         JOptionPane.showMessageDialog(null, "Directory for datafile does not exist - Data file could not be created.", "Error", JOptionPane.ERROR_MESSAGE);
      }
   }
   /**
   *Adds modifications to file (saves)
   */
   public static void save(){
      try{
         /** writes onto file*/
         FileWriter dataWriter = new FileWriter(dataFile);
         for (int i = 1; i < (FlightInfo.getFlightNum() + 1); i++){
            dataWriter.write("Flight " + i + "\n");
            dataWriter.write(FlightInfo.getFlightNumInfo(i-1) + ", " + FlightInfo.getFlightTicketCost(i-1) + "\n");
            for (int row = 0; row < 5; row++){
               for (int column = 0; column < 2; column++){
                  if (!FlightInfo.checkFlightSeat(i-1, row, column))
                     dataWriter.write("null");
                  else {
                     dataWriter.write(Arrays.toString(FlightInfo.getFlightSeatData(i-1, row, column)));
                  }
                  dataWriter.write("\n");
               }
            }
         }
         dataWriter.close();
      }
      catch (IOException e){
         JOptionPane.showMessageDialog(null, "Data file not found!", "Error", JOptionPane.ERROR_MESSAGE);
      }
   }
   /** reads data from file */
   public static void read(){
      /** line on text file */
      String inputLine;
      /** array of inputs */
      String[] inputArray;
      /**flight number */
      int flight;
      try{
         BufferedReader b = new BufferedReader(new FileReader(dataFile));
         while ((inputLine = b.readLine()) != null){
            inputArray = inputLine.replace(']', ' ').split(" ");
            flight = Integer.parseInt(inputArray[1]);
            inputLine = b.readLine();
            inputArray = inputLine.split(", ");
            FlightInfo.addFlight(new Flight(inputArray[0], inputArray[1], Integer.parseInt(inputArray[2]), Integer.parseInt(inputArray[3])));
            for (int row = 0; row < 5; row++){
               for (int column = 0; column < 2; column++){
                  if (!(inputLine = b.readLine()).equals("null")){
                     inputArray = inputLine.replace(']', ' ').split(", ");
                     FlightInfo.setFlightSeat((flight-1), new Customer(inputArray[1], inputArray[2], inputArray[3], Integer.parseInt(inputArray[4]), inputArray[5], inputArray[6]), row, column);
                  }
               }
            }
         }
      }
      catch (IOException e){
      }
   }
}
         