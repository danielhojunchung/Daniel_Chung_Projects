/* Michael Wang, Daniel Chung
   Ms. Basaraba
   June 10, 2023
   Manages GUI components including drawings, responds to user input*/
   
/* Modification
   May 15 2023
   Daniel Chung
   75 min
   Version 1
   Created DrawBackground class, created drawing for background */
   
/* Modification
   May 16 2023
   Michael Wang
   50 min
   Version 1
   Modified constructor class, actionPerformed. Created code for main menu  */

/* Modification
   May 17 2023
   Daniel Chung
   75 min
   Version 1
   Debugged AtlasAirlines Constructor class */

/* Modification
   May 23 2023
   Daniel Chung
   75 min
   Version 2
   Created DrawSeats class, created background for seat selection */

/* Modification
   May 23 2023
   Michael Wang
   75 min
   Version 2
   Created DrawBackground class, created drawing for background */

/* Modification
   May 24 2023
   Daniel Chung
   75 min
   Version 2
   Modified AtlasAirlines constructor and DrawSeats class to add buttons on top of background */

/* Modification
   May 25 2023
   Daniel Chung
   75 min
   Version 2
   Created DrawAnimation class, modified AtlasAirlines constructor, main method to create animation at start of program */
   
/* Modification
   May 29 2023
   Daniel Chung
   75 min
   Version 3
   Modified constructor, DrawSeats class, experimented with JLayeredPane */

/* Modification
   May 29 2023
   Michael Wang
   75 min
   Version 3
   Modified constructor, DrawSeats class, experimented with JLayeredPane */
   
/* Modification
   May 30 2023
   Daniel Chung
   75 min
   Version 3
   Modified constructor, DrawSeats class, experimented with JLayeredPane */
   
/* Modification
   May 30 2023
   Michael Wang
   75 min
   Version 3
   Modified constructor, DrawSeats class, implemented JLayeredPane */
   
/* Modification
   June 5 2023
   Daniel Chung
   75 min
   Version 4
   Modified DrawAnimation class, continued start-up animation */
   
/* Modification
   June 7 2023
   Daniel Chung
   15 min
   Version 4
   Modified DrawAnimation class, finished start-up animation */
   
/* Modification
   June 8 2023
   Michael Wang
   35 min
   Version 4
   Solved errors in constructor, bookSeat */
   
/* Modification
   June 11 2023
   Daniel Chung
   150 min
   Version 5
   Added option to print passenger manifest */
   
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.table.DefaultTableModel;

/**
*AtlasAirlines class.
*Driver Class
*Michael Wang, Daniel Chung.
*/
public class AtlasAirlines extends JFrame implements ActionListener{
   /**Array of Return buttons (returns to main menu)*/
   JButton[] menuB = new JButton[3];
   /** Buttons that change page */
   JButton nextB, lastB;
   /**Buttons available on main menu*/
   JButton flightB, custB, salesB, saveB, printB, fCancelB, uManB;
   /**Panels to placed in border layout for main menu*/
   JPanel top, topSub, bot, mid;
   /**JPanel holding entire main menu*/
   JPanel mainMenu = new JPanel();
   /**JPanel holding entire flight info section*/
    
   JPanel flightInfo;
   /**Panels to be placed in border layout for flight info section*/
   JPanel top1, mid1, bot1, bot1sub, bot1subHolder;
   /** Buttons to access flights*/
   JButton[] flights;
   /** Panel to store buttons */
   JPanel buttonPanel;
   
   /**Layered Pane to allow graphical overlay over seat registry*/
   JLayeredPane flightLayeredPane;
   /** Panel to contain flight register*/
   JPanel flight;
   /** Panels to contain varius GUI elements*/
   JPanel top2, left2, mid2, right2, bot2;
   /** Label to state flight*/
   JLabel flightHeader;
    
   /** Panel to contain customer information*/
   JPanel custInfo;
   /** Panels for main menu*/
   JPanel top3, mid3, bot3;
   
   /**array of seats*/
   JButton[][] seatsB = new JButton[5][2];
   /** panel to hold seat rows */
   JPanel[] rowHolder = new JPanel[5];
   
   /** first name of customer*/   
   private static String fname;
   /** last name of customer*/
   private static String lname;
   /** date of birth of customer*/
   private String DOB;
   /** age of customer*/
   private int age;
   /** phone number of customer*/
   private String phone;
   /** email of customer*/
   private String email;
   /** number of tickets sold*/
   private static int ticketSales = 0;
   /** a DrawSeats object*/ 
   DrawSeats d;
   /** an array of column names, used for JTable*/ 
   JPanel cardPanel;
   /** current page in selection screen */
   private int currentPage;
   /** array for headers in customer information table */
   private String[] columnNames = {"Seat Number", "First Name", "Last Name", "Date of Birth", "Age", "Phone Number", "Email"};;
   
   /**
   *Constructor class
   *@param title Title for screen
   */
   public AtlasAirlines(String title){
      super(title);
      cardPanel = new JPanel();
      top = new JPanel();
      topSub = new JPanel();
      mid = new JPanel();
      bot = new JPanel();
      for (int l = 0; l < 3; l++){
         menuB[l] = new JButton("Return");
         menuB[l].setFont(new Font("Serif", Font.PLAIN, 24));
         menuB[l].addActionListener(this);
         menuB[l].setActionCommand("menuB");
      }
      flightB = new JButton("Flight Information");
      custB = new JButton("Customer Information");
      salesB = new JButton("Sales");
      saveB = new JButton("Save");
      printB = new JButton("Print Passenger Manifest");
      fCancelB = new JButton("Flight Cancellations");
      uManB = new JButton("User Manual");
      nextB = new JButton("Next");
      lastB = new JButton("Last");
      flightB.setFont(new Font("Serif", Font.PLAIN, 34));
      custB.setFont(new Font("Serif", Font.PLAIN, 34));
      salesB.setFont(new Font("Serif", Font.PLAIN, 34));
      saveB.setFont(new Font("Serif", Font.PLAIN, 34));
      printB.setFont(new Font("Serif", Font.PLAIN, 34));
      fCancelB.setFont(new Font("Serif", Font.PLAIN, 34));
      uManB.setFont(new Font("Serif", Font.PLAIN, 34));
      nextB.setFont(new Font("Serif", Font.PLAIN, 24));
      lastB.setFont(new Font("Serif", Font.PLAIN, 24));
      flightB.addActionListener(this);
      printB.addActionListener(this);
      custB.addActionListener(this);
      salesB.addActionListener(this);
      saveB.addActionListener(this);
      fCancelB.addActionListener(this);
      printB.addActionListener(this);
      uManB.addActionListener(this);
      nextB.addActionListener(this);
      lastB.addActionListener(this);
      flightB.setActionCommand("flightB");
      printB.setActionCommand("printB");
      custB.setActionCommand("custB");
      salesB.setActionCommand("salesB");
      saveB.setActionCommand("saveB");
      fCancelB.setActionCommand("fCancelB");
      uManB.setActionCommand("uManB");
      nextB.setActionCommand("nextB");
      lastB.setActionCommand("lastB");
      top.setLayout(new GridLayout(1, 3));
      topSub.setLayout(new GridLayout(1, 2));
      bot.setLayout(new GridLayout(1, 3));
      mid.setLayout(new GridLayout(1, 1));
      top.add(flightB);
      top.add(custB);
      topSub.add(salesB);
      topSub.add(saveB);
      top.add(topSub);
      bot.add(printB);
      bot.add(fCancelB);
      bot.add(uManB);
      mid.add(new DrawBackground());
      mainMenu.setLayout(new BorderLayout());
      mainMenu.add(top, BorderLayout.NORTH);
      mainMenu.add(mid, BorderLayout.CENTER);
      mainMenu.add(bot, BorderLayout.SOUTH);
      
      setResizable(false);
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      
      flightInfo = new JPanel();
      top1 = new JPanel();
      mid1 = new JPanel();
      bot1 = new JPanel();
      bot1sub = new JPanel();
      bot1subHolder = new JPanel();
      buttonPanel = new JPanel(new GridLayout(10, 1, 0, 2));
      flightInfo.setLayout(new BorderLayout());
      JLabel flightLbl = new JLabel ("Flight Listing");
      flightLbl.setFont(new Font("Serif", Font.BOLD, 24));
      bot1.setLayout(new BorderLayout());
      top1.add(flightLbl);
      bot1sub.add(lastB);
      bot1sub.add(menuB[0]);
      bot1sub.add(nextB);
      bot1.add(bot1subHolder, BorderLayout.NORTH);
      bot1.add(bot1sub, BorderLayout.CENTER);
      flightInfo.add(top1, BorderLayout.NORTH);
      flightInfo.add(mid1, BorderLayout.CENTER);
      flightInfo.add(bot1, BorderLayout.SOUTH);
      
      flightLayeredPane = new JLayeredPane();
      flight = new JPanel();
      flight.setLayout(new BorderLayout());
      top2 = new JPanel();
      left2 = new JPanel();
      left2.setPreferredSize(new Dimension(400, 500));
      mid2 = new JPanel();
      right2 = new JPanel();
      right2.setPreferredSize(new Dimension(400, 500));
      bot2 = new JPanel();
      bot2.add(menuB[1]);
      mid2.setLayout(new GridLayout(5, 3));
      d = new DrawSeats();
      d.setBounds(0, 0, 1200, 600);
      top2.setOpaque(false);
      left2.setOpaque(false);
      mid2.setOpaque(false);
      right2.setOpaque(false);
      bot2.setOpaque(false);
      
      custInfo = new JPanel();
      custInfo.setLayout(new BorderLayout());
      top3 = new JPanel();
      mid3 = new JPanel();
      bot3 = new JPanel();
      bot3.add(menuB[2]);
      mid3.setLayout(new BoxLayout(mid3, BoxLayout.Y_AXIS));
      custInfo.add(top3, BorderLayout.NORTH);
      
      setSize(1200, 600);
      setVisible(true);
      
      try{
         for (int i = 0; i < 400; i++){
            setContentPane(new DrawAnimation(i));
            repaint();
            revalidate();
            Thread.sleep(10);
         }
      }
      catch (InterruptedException e){}
      setContentPane(mainMenu);
      repaint();
      revalidate();
   }
   
   /**
   *Determines how to respond to events
   *@param evt the ActionEvent
   */
   public void actionPerformed(ActionEvent evt){
      if (evt.getActionCommand().equals("menuB")){
         openMainMenu();
      }
      if (evt.getActionCommand().equals("flightB")){
         flightInfoOpen();
      }
      else if (evt.getActionCommand().equals("custB")){
         openCustomerInfo();
      }
      else if (evt.getActionCommand().equals("printB")){
         openPrint();
      }
      else if (evt.getActionCommand().equals("fCancelB")){
         flightCancelOpen(); 
      }
      else if (evt.getActionCommand().equals("uManB")){
         UserManual.openUserManual();
      }
      else if (evt.getActionCommand().equals("saveB")){
         SaveFile.save();
      }
      else if (evt.getActionCommand().equals("salesB")){
         salesInfo();
      }
      else if (evt.getActionCommand().equals("nextB")){
         currentPage++;
         updateButtonPanel(buttonPanel);
      }
      else if (evt.getActionCommand().equals("lastB")){
         currentPage--;
         updateButtonPanel(buttonPanel);
      }
      else {
         String[] temp = evt.getActionCommand().split(" ");
         if (temp[0].equals("Book"))
            bookFlight(Integer.parseInt(temp[1]), Integer.parseInt(temp[2]), Integer.parseInt(temp[3]));
         else if (temp[0].equals("Cancel"))
            cancelFlightSeat(Integer.parseInt(temp[1]), Integer.parseInt(temp[2]), Integer.parseInt(temp[3]));
         else if (temp[0].equals("FCancel"))
            cancelFlight(Integer.parseInt(temp[1]));
         else if (temp[0].equals("FInfo"))
            openCustomerTable(Integer.parseInt(temp[1]));
         else if (temp[0].equals("bc"))
            flightOpen(Integer.parseInt(temp[1]));
         else if (temp[0].equals("print")){
            String[] options = {"By Seat", "By Name"};
            int sortChoice = JOptionPane.showOptionDialog(this, "Select sorting method:",
                        "Print Passenger Manifest", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
               null, options, "By Seat");
               
            if (sortChoice == 0){
               PrintPassengers.printPassengers(Integer.parseInt(temp[1]), false);
            }
            else if (sortChoice == 1){
               PrintPassengers.printPassengers(Integer.parseInt(temp[1]), true);
            }
         }
      }        
   } 
   
   /**
   *Calls ActionCommand that prints passenger manifest
   */
   private void openPrint(){
      flightList("print");   
   }
   
   /**
   *Opens the main menu
   */
   private void openMainMenu(){
      setContentPane(mainMenu);
      repaint();
      revalidate();
      currentPage=0;
   }
   
   /**
   *Opens the Flight Info screen
   */
   private void flightInfoOpen(){
      flightList("bc");
   }
   
   /**
   *Opens the flight screen
   *Modified: adjusted the values of the bounds of the panels. Added the flight header and changed its font.
   *@param zz the index of flightList of the flight being opened
   */
   private void flightOpen(int zz){
      mid2.removeAll();
      top2.removeAll();
      for (int b = 0; b < 5; b++){
         if (FlightInfo.checkFlightSeat(zz, b, 0)){
            seatsB[b][0] = new JButton("/");
            seatsB[b][0].setActionCommand("Cancel " + String.valueOf(zz) + " " + String.valueOf(b) + " " + String.valueOf(0));
            seatsB[b][0].setBackground(new Color(222, 222, 222));
         }
         else{
            seatsB[b][0] = new JButton("+");
            seatsB[b][0].setActionCommand("Book " + String.valueOf(zz) + " " + String.valueOf(b) + " " + String.valueOf(0)); 
         }
         seatsB[b][0].addActionListener(this);
         mid2.add(seatsB[b][0]);
         rowHolder[b] = new JPanel();
         rowHolder[b].setOpaque(false);
         mid2.add(rowHolder[b]);
         if (FlightInfo.checkFlightSeat(zz, b, 1)){
            seatsB[b][1] = new JButton("/");
            seatsB[b][1].setActionCommand("Cancel " + String.valueOf(zz) + " " + String.valueOf(b) + " " + String.valueOf(1));
            seatsB[b][1].setBackground(new Color(222, 222, 222));
         }
         else{
            seatsB[b][1] = new JButton("+");
            seatsB[b][1].setActionCommand("Book " + String.valueOf(zz) + " " + String.valueOf(b) + " " + String.valueOf(1)); 
         }
            seatsB[b][1].addActionListener(this);
            mid2.add(seatsB[b][1]);   
      }
      flight.setBounds(0, 0, 1200, 560);
      flightHeader = new JLabel("Flight " + (zz+1));
      flightHeader.setFont(new Font("Serif", Font.PLAIN, 28));
      top2.add(flightHeader);
      flight.add(top2, BorderLayout.NORTH);
      flight.add(left2, BorderLayout.WEST);
      flight.add(mid2, BorderLayout.CENTER);
      flight.add(right2, BorderLayout.EAST);
      flight.add(bot2, BorderLayout.SOUTH);
      flightLayeredPane.removeAll();
      d.setOpaque(false);
      flight.setOpaque(false);
      flightLayeredPane.add(d, Integer.valueOf(0));
      flightLayeredPane.add(flight, Integer.valueOf(1));
      setContentPane(flightLayeredPane);
      repaint();
      revalidate();
   }     
   
   /**
   *Books the seat of a flight
   *@param z the index of the flight in flightList
   *@param zx the row of the seat
   *@param zy the column of the seat
   */
   private void bookFlight(int z, int zx, int zy){
      /** boolean of validity */
      boolean valid = false;
      while (!valid){
         fname = JOptionPane.showInputDialog(this, "Please enter your first name: ", "Booking column " + (zy+1) + " row " + (zx+1), JOptionPane.QUESTION_MESSAGE);
         if (fname == null)
            return;
         try{
            fname = fname.substring(0,1).toUpperCase() + fname.substring (1);
            valid = true;
         }
         catch (Exception e){
            JOptionPane.showMessageDialog(this, "Invalid input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
         }
      }
      valid = false;
      while (!valid){
         lname = JOptionPane.showInputDialog(this, "Please enter your last name: ", "Booking column " + (zy+1) + " row " + (zx+1), JOptionPane.QUESTION_MESSAGE);
         if (lname == null)
            return;
         try{
            lname = lname.substring(0,1).toUpperCase() + lname.substring (1);
            valid = true;
         }
         catch (Exception e){
            JOptionPane.showMessageDialog(this, "Invalid input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
         }
      }
      valid = false;
      while (!valid){
         DOB = JOptionPane.showInputDialog(this, "Please enter your date of birth (MM/DD/YYYY): ", "Booking column " + (zy+1) + " row " + (zx+1), JOptionPane.QUESTION_MESSAGE);
         if (DOB == null)
            return;
         if (DataCheck.checkDOB(DOB))
            valid = true;
         else
            JOptionPane.showMessageDialog(this, "Invalid input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
      }
      
      valid = false;
      while (!valid){
         String ageS = JOptionPane.showInputDialog(this, "Please enter your age in years: ", "Booking column " + (zy+1) + " row " + (zx+1), JOptionPane.QUESTION_MESSAGE);
         if (ageS == null)
            return;
         if (DataCheck.isNumeric(ageS) && DataCheck.checkAge(ageS, DOB)){
            age = Integer.parseInt(ageS);
            valid = true;
         }
         else
            JOptionPane.showMessageDialog(this, "Invalid input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
      }
      
      valid = false;
      while (!valid){
         phone = JOptionPane.showInputDialog(this, "Please enter your phone number (seperated by spaces, dashes, or none): ", "Booking column " + (zy+1) + " row " + (zx+1), JOptionPane.QUESTION_MESSAGE);
         if (phone == null)
            return;
         if (DataCheck.checkPhone(phone))
            valid = true;
         else
            JOptionPane.showMessageDialog(this, "Invalid input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
      }
      
      valid = false;
      while (!valid){
         email = JOptionPane.showInputDialog(this, "Please enter your email: ", "Booking column " + (zy+1) + " row " + (zx+1), JOptionPane.QUESTION_MESSAGE);
         if (email == null)
            return;
         if (DataCheck.checkEmail(email))
            valid = true;
         else
            JOptionPane.showMessageDialog(this, "Invalid input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
      }
      
      if (JOptionPane.showConfirmDialog(this, "Are you sure you want to book this seat: " + ((zx)*2+(zy)+1) + " on column: " + (zy+1) + " and row: " + (zx+1) + " for $" + FlightInfo.getFlightTicketCost(z) + "?", "Confirm Booking", JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION){
         FlightInfo.setFlightSeat(z, new Customer(fname, lname, DOB, age, phone, email), zx, zy);
         ticketSales++;
         flightOpen(z);
         JOptionPane.showMessageDialog(this, "Booking successful!", "Notice", JOptionPane.INFORMATION_MESSAGE);
      }
      else
         return;
   }
   
   /**
   *cancels the booking of a seat in a flight
   *@param z the index of the flight in flightList
   *@param zx the row of the seat
   *@param zy the column of the seat
   */
   private void cancelFlightSeat(int z, int zx, int zy){
      if (JOptionPane.showConfirmDialog(this, "Are you sure you want to cancel the booking of this seat: " + ((zx)*2+(zy)+1) + " on column: " + (zy+1) + " and row: " + (zx+1) + "?", "Confirm Cancellation", JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION){
         ticketSales--;
         FlightInfo.setFlightSeat(z, null, zx, zy);
         flightOpen(z);
         JOptionPane.showMessageDialog(this, "Cancellation successful!", "Notice", JOptionPane.INFORMATION_MESSAGE);
      }
      else
         return;
   }
   /**
   *Opens the list of flights, sets the command of the buttons to something including FCancel
   */
   private void flightCancelOpen(){
      flightList("FCancel");
   }
   
   /**
   *Cancels the flight entirely
   *@param z the index of the flight on flightList
   */
   private void cancelFlight(int z){
      if (JOptionPane.showConfirmDialog(this, "Are you sure you want to cancel flight number: " + (z+1) + "?", "Confirm Flight Cancellation", JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION){
         FlightInfo.cancelFlight(z);
         flightCancelOpen();
         JOptionPane.showMessageDialog(this, "Flight cancellation successful!", "Notice", JOptionPane.INFORMATION_MESSAGE);
         if (JOptionPane.showConfirmDialog(this, "Do you want to print the passenger manifest?", "Print Passenger Manifest", JOptionPane.INFORMATION_MESSAGE) == JOptionPane.YES_OPTION)
            PrintPassengers.printPassengers(z, false);
      }
      else
         return;
   }
   
   /**
   *Opens the flight list and sets the button commands to something that starts with "FInfo "
   */
   private void openCustomerInfo(){
      flightList("FInfo");
   }
    
   /**
   *Opens the data for a flight, in table format
   *@param y the index of the flight on flightList
   */
   private void openCustomerTable(int y){
      mid3.removeAll();
      DefaultTableModel infoTable = new DefaultTableModel(FlightInfo.getFlightData(y), columnNames){
         @Override
         public boolean isCellEditable(int row, int column){
            return false;
         }
      };
      JTable custTable = new JTable(infoTable);
      custTable.getTableHeader().setReorderingAllowed(false);
      mid3.add(new JScrollPane(custTable));
      custInfo.add(mid3, BorderLayout.CENTER);
      custInfo.add(bot3, BorderLayout.SOUTH);
      setContentPane(custInfo);
      revalidate();
      repaint();
   }
   
   /**
   *Method to create list of flight buttons
   *@param cmd Command
   */ 
   private void flightList(String cmd){ //Optimization method to reduce code length
      currentPage = 0;
      int flightNum = FlightInfo.getFlightNum();
      flights = new JButton[flightNum];
      mid1.removeAll();
      for (int i = 0; i < flightNum; i++){
         flights[i] = new JButton(FlightInfo.getFlightNumInfo(i));
         flights[i].setFont(new Font("Serif", Font.PLAIN, 20));
         flights[i].addActionListener(this);
         flights[i].setActionCommand(cmd + " " + String.valueOf(i));
      }
      updateButtonPanel(buttonPanel);
      mid1.add(buttonPanel);
      cardPanel.add(flightInfo, "flightListPanel");
      setContentPane(cardPanel);
      repaint();
      revalidate();
   }
   
   /**
   *Updates panel of buttons
   *@param buttonPanel panel for buttons
   */
   private void updateButtonPanel(JPanel buttonPanel) {
      buttonPanel.removeAll();
      buttonPanel.setLayout(new GridLayout(10, 1, 0, 5));
      int startIndex = currentPage * 10;
      int endIndex = Math.min(startIndex + 10, flights.length);
      for (int i = startIndex; i < endIndex; i++) {
         buttonPanel.add(flights[i]);
      }

      nextB.setEnabled(endIndex < flights.length);
      lastB.setEnabled(startIndex > 0);

      repaint();
      revalidate();
   }
   
   /**
   *Keeps track of sales
   */
   public void salesInfo(){
      int totalSales = 0;
      int totalSalesValue = 0;
      for (int i = 0; i < FlightInfo.getFlightNum(); i++){
         totalSales += FlightInfo.getFlightSeatCount(i);
         totalSalesValue += (FlightInfo.getFlightSeatCount(i)*FlightInfo.getFlightTicketCost(i));
      }
      JOptionPane.showMessageDialog(this, "Tickets sold: " + totalSales, "Sales", JOptionPane.INFORMATION_MESSAGE);
      JOptionPane.showMessageDialog(this, "Total sales: " + totalSalesValue, "Sales", JOptionPane.INFORMATION_MESSAGE);
   }
   
   /**
   *Main method
   *@param args Array of arguments
   */ 
   public static void main (String[] args){
      AtlasAirlines m = new AtlasAirlines ("Atlas Airlines");
      SaveFile.createFile();
      SaveFile.read();
      SaveFile.save();
   }
   
   /**
   *DrawBackground class.
   *Draws background for home page
   *Daniel Chung.
   */
   class DrawBackground extends JComponent{
      /**
      *Constructor method
      */
      public DrawBackground(){
      }
      /**
      *Paints drawings
      *@param g Graphics 
      */
      public void paint (Graphics g){
         /** Color Dark Grey*/
         Color DarkGrey = new Color(70, 70, 70);
         g.setColor(DarkGrey);
         /** array of x-coordinates */
         int[] xList1 = {0, 0, 1200, 1200};
         /** array of y-coordinates */
         int[] yList1 = {220, 600, 600, 370};
         g.fillPolygon(xList1, yList1, 4);
         
         /** Color Mahagony*/
         Color Mahagony = new Color(180, 10, 20);
         g.setColor(Mahagony);
         /** array of x-coordinates */
         int[] xList2 = {0, 0, 1200, 1200};
         /** array of y-coordinates */
         int[] yList2 = {0, 220, 370, 0};
         g.fillPolygon(xList2, yList2, 4);
         
         /** Color Light Grey*/
         Color LightGrey = new Color (170, 170, 170);
         g.setColor(LightGrey);
         g.fillOval(750, 120, 300, 300);
         
         /** Color Blue*/
         Color Blue = new Color (10, 20, 210);
         g.setColor(Blue);
         g.fillOval(800, 140, 245, 245);
         
         /** Color White*/
         Color White = new Color(255, 255, 255);
         g.setColor(White);
         /** array of x-coordinates */
         int[] xList3 = {990, 884, 938};
         /** array of y-coordinates */
         int[] yList3 = {190, 296, 331};
         g.fillPolygon(xList3, yList3, 3);
         
         /** Color Off White*/
         Color OffWhite = new Color(230, 230, 230);
         g.setColor(OffWhite);
         /** array of x-coordinates */
         int[] xList4 = {964, 938, 970};
         /** array of y-coordinates */
         int[] yList4 = {261, 331, 341};
         g.fillPolygon(xList4, yList4, 3);
         /** array of x-coordinates */
         int[] xList5 = {937, 884, 861};
         /** array of y-coordinates */
         int[] yList5 = {243, 296, 270};
         g.fillPolygon(xList5, yList5, 3);
         
         /** Color Yellow*/
         Color Yellow = new Color(245, 240, 10);
         g.setColor(Yellow);
         g.fillRect(20, 20, 1140, 10);
         g.fillRect(1160, 20, 10, 420);
         g.fillRect(20, 20, 10, 420);
         g.fillRect(20, 430, 1140, 10);

         /** Color Black*/
         Color Black = new Color(20, 20, 20);
         g.setColor(Black);
         Font fontElephant = new Font ("Elephant", Font.PLAIN, 55);
         g.setFont(fontElephant);   
         g.drawString("Atlas Airlines", 70, 120);  
      }
   }
   
   /**
   *DrawSeats class.
   *Draws background for flight selection
   *Daniel Chung.
   */
   class DrawSeats extends JComponent{
      
      /**
      *Constructor method
      */
      public DrawSeats(){
      }
      
      /**
      *Paints drawings
      *@param g Graphics 
      */
      public void paint (Graphics g){
         /** Color Light Gray*/
         Color LightGray = new Color(200, 200, 200);
         g.setColor(LightGray);
         g.fillRect(400, 0, 400, 600);
         /** Color Sky Blue*/
         Color SkyBlue = new Color(56, 219, 255);
         g.setColor(SkyBlue);
         g.fillRect(0, 0, 400, 600);
         g.fillRect(804, 0, 400, 600);
         /** Color Gray*/
         Color Gray = new Color(160, 160, 160);
         g.setColor(Gray);
         g.fillRect(180, 120, 80, 100);
         g.fillRect(960, 120, 80, 100);
         /** Color Dark Gray*/
         Color DarkGray = new Color(90, 90, 90);
         g.setColor(DarkGray);
         /** array of x-coordinates */
         int xList1[] = {400, 400, 0, 0};
         /** array of y-coordinates */
         int yList1[] = {120, 400, 400, 240};
         g.fillPolygon(xList1, yList1, 4);
         /** array of x-coordinates */
         int xList2[] = {804, 804, 1200, 1200};
         /** array of y-coordinates */
         int yList2[] = {120, 400, 400, 240};
         g.fillPolygon(xList2, yList2, 4);
         /** Color Black*/
         Color Black = new Color(20, 20, 20);
         g.setColor(Black);
         /** Font Elephant */
         Font fontElephant = new Font ("Elephant", Font.PLAIN, 55);
         g.setFont(fontElephant);
         g.drawString("-1-", 570, 102);
         g.drawString("-2-", 568, 198);
         g.drawString("-3-", 568, 294);
         g.drawString("-4-", 568, 390);
         g.drawString("-5-", 568, 486);
         g.fillRect(396, 0, 4, 600);
         g.fillRect(799, 0, 5, 600);

      }
   }
   /**
   *DrawAnimation class.
   *Draws startup animation
   *Daniel Chung.
   */
   class DrawAnimation extends JComponent{
      /**time index*/
      int i;
      /**
      *Constructor method
      *@param i time index
      */
      public DrawAnimation(int i){
         this.i = i;
      }
      /**
      *Paints drawings
      *@param g Graphics 
      */
      public void paint (Graphics g){
         /** Color Dark Grey*/
         Color DarkGrey = new Color(70, 70, 70);
         g.setColor(DarkGrey);
         
         Color Mahagony = new Color(180, 10, 20);
         /** array of x-coordinates */
         int[] xList1 = {0, 0, 1200, 1200};
         /** array of y-coordinates */
         int[] yList1 = {220, 600, 600, 370};
         /** array of x-coordinates */
         int[] xList2 = {0, 0, 1200, 1200};
         /** array of y-coordinates */
         int[] yList2 = {0, 220, 370, 0};
         
         if(i<150){
            xList1[0] = i*8-1200;
            xList1[1] = i*8-1200;
            xList1[2] = i*8; 
            xList1[3] = i*8;
            g.fillPolygon(xList1, yList1, 4);
         }
         else{
            g.fillPolygon(xList1, yList1, 4);
         }
         
         g.setColor(Mahagony);

         if(70<i && i<220){
            xList2[0] = 1200-(i-70)*8;
            xList2[1] = 1200-(i-70)*8;
            xList2[2] = 2400-(i-70)*8;
            xList2[3] = 2400-(i-70)*8;
            g.fillPolygon(xList2, yList2, 4);
         }
         else if(i >= 220){
            g.fillPolygon(xList2, yList2, 4);
         }
         
         /** Color Light Grey*/
         Color LightGrey = new Color (170, 170, 170);
         g.setColor(LightGrey);
         g.fillOval(750, 120, 300, 300);
         
         /** Color Blue*/
         Color Blue = new Color (10, 20, 210);
         g.setColor(Blue);
         g.fillOval(800, 140, 245, 245);
         
         /** Color Yellow*/
         Color Yellow = new Color(245, 240, 10);
         g.setColor(Yellow);
         g.fillRect(20, 20, 1140, 10);
         g.fillRect(1160, 20, 10, 520);
         g.fillRect(20, 20, 10, 520);
         g.fillRect(20, 530, 1140, 10);
         
         /** Color White*/
         Color White = new Color(255, 255, 255);
         /** Color White*/
         Color OffWhite = new Color(230, 230, 230);
         
         /** array of x-coordinates */   
         int[] xList3 = {990, 884, 938};
         /** array of y-coordinates */
         int[] yList3 = {190, 296, 331};
         /** array of x-coordinates */
         int[] xList4 = {964, 938, 970};
         /** array of y-coordinates */
         int[] yList4 = {261, 331, 341};
         /** array of x-coordinates */
         int[] xList5 = {937, 884, 861};
         /** array of y-coordinates */
         int[] yList5 = {243, 296, 270};
         
         if (i>240 && i<320){
            yList3[0] = 190-400+(i-240)*5;
            yList3[1] = 296-400+(i-240)*5;
            yList3[2] = 331-400+(i-240)*5;
            yList4[0] = 261-400+(i-240)*5;
            yList4[1] = 331-400+(i-240)*5;
            yList4[2] = 341-400+(i-240)*5;
            yList5[0] = 243-400+(i-240)*5;
            yList5[1] = 296-400+(i-240)*5;
            yList5[2] = 270-400+(i-240)*5;
            
            g.setColor(White);
            g.fillPolygon(xList3, yList3, 3); 
            g.setColor(OffWhite);
            g.fillPolygon(xList4, yList4, 3);     
            g.fillPolygon(xList5, yList5, 3);
         }
         
         else if(i >=320){
            g.setColor(White);
            g.fillPolygon(xList3, yList3, 3); 
            g.setColor(OffWhite);
            g.fillPolygon(xList4, yList4, 3);     
            g.fillPolygon(xList5, yList5, 3);
         }
         

         /** Color Black*/
         Color Black = new Color(20, 20, 20);
         g.setColor(Black);
         /** Font Elephant */
         Font fontElephant = new Font ("Elephant", Font.PLAIN, 55);
         g.setFont(fontElephant);   
         g.drawString("Loading...", 70, 120);  
      }
   }
}